# Audio Studio (Android)

A dark-theme Android multitrack audio-session starter project built with Kotlin and Jetpack Compose.

## Included
- Import multiple audio files using Android's document picker
- Track list with individual volume, mute, solo and remove controls
- Simultaneous playback of eligible tracks
- Master output control, play, pause and stop
- Dark professional studio-style interface

## Build an APK
1. Install Android Studio (Ladybug or newer) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
This is a functional starter, not a finished DAW. The waveform display is a visual placeholder, not a decoded audio waveform. Playback uses Android MediaPlayer and does not yet provide sample-accurate sync, trimming, effects, automation, recording, or a rendered/exported mix. Track playback begins when each player is prepared, so precise synchronization is not guaranteed. A production studio app needs a dedicated low-latency audio engine and an audio-mix/export pipeline.
